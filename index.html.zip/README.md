# Rocket Runner – Asteroid Edition (v6)

Flappy-style browser game where you pilot a rocket through **uniform asteroid belts**. Pure HTML5 Canvas + WebAudio.

### What’s in v6
- **Physics:** gravity `0.05`, thrust `0.10`, max vertical speed `0.08` (all × `unit`).
- **Scroll:** ~half the previous base speed, with a gentle +30% time-based ramp.
- **Start flow:** Start → first tap to begin movement.
- **Uniform belts:** neat grid of rocks (pipe-like edges).
- **Forgiving hitboxes:** inset belts + slightly smaller rocket.
- **Mobile friendly**, chiptune music (press `M` / 🔊 to mute).

## Run
Open `index.html` in a browser.

## Publish on GitHub Pages
- Push/Upload `index.html` to your repo root
- Settings → Pages → Source: `main` / `(root)` → Save
